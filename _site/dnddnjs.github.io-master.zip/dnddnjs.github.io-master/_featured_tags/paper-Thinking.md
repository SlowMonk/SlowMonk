---
layout: tag-blog
title: Thinking
slug: Thinking
category: paper
menu: false
order: 3
---
