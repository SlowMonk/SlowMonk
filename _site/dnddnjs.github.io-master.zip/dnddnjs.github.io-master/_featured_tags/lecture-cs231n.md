---
layout: tag-blog
title: cs231n
slug: cs231n
category: lecture
menu: false
order: 1
---
